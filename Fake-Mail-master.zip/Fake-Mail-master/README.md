[Fake-Mail](https://github.com/The404Hacking/Fake-Mail)
=========

Send fake e-mails to anyone, with custom sender. Use it at your own risks. 

Feel free to use it, edit it and do whatever you want. [Share](https://telegram.me/share/url?url=https://github.com/The404Hacking/Fake-Mail&text=Fake%20Mail%20PHP%20Script)

## Download and Clone
> Download: [https://github.com/The404Hacking/Fake-Mail/archive/master.zip](https://github.com/The404Hacking/Fake-Mail/archive/master.zip)

> Clone: git clone [https://github.com/The404Hacking/Fake-Mail.git](https://github.com/The404Hacking/Fake-Mail.git)

## The404Hacking | Digital UnderGround Team
[The404Hacking](https://T.me/The404Hacking)

## Follow us !
[The404Hacking](https://T.me/The404Hacking) - [The404Cracking](https://T.me/The404Cracking)

[Instagram](https://instagram.com/The404Hacking) - [GitHub](https://github.com/The404Hacking)

[YouTube](http://yon.ir/youtube404) - [Aparat](http://www.aparat.com/The404Hacking)

[The404Hacking.BlogSky.Com](http://the404hacking.blogsky.com)
